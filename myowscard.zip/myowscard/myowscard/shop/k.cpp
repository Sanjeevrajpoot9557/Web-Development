#include<iostream>
#include<string>
#include<algorithm>
using namespace std;
 int help(int num){
 string s= to_string(num);
    string cpy = s;
    sort(s.begin(),s.end());
    cout<<s<<endl;
    sort(cpy.begin(),cpy.end(),greater<int>());
    cout<<cpy<<endl;

    int res = stoi(s)+stoi(cpy);  
     return res;
 }

int main(){
    int num;
    cin>>num;
  cout<<help(num);
    return 0;
}