from django.shortcuts import render
from .models import Product, Contact, Orders, OrderUpdate
from math import ceil
from django.http import HttpResponse
import json
# import requests
# import json
# import PaytmChecksum
from django.views.decorators.csrf import csrf_exempt
# from paytmchecksum import PaytmChecksum

# from PayTm import Checksum

# Create your views here.
MERCHANT_KEY = 'c4eENrV4V7ZZZ_go'



def index(request):
    # products = Product.objects.all()
    # print(products)

    # n = len(products)
    # nSlides = n // 4 + ceil((n / 4) - (n // 4))

    allProds = []
    catProds = Product.objects.values('category', 'id')
    cats = {item['category'] for item in catProds}
    for cat in cats:
        prod = Product.objects.filter(category=cat)
        n = len(prod)
        nSlides = n // 4 + ceil((n / 4) - (n // 4))
        allProds.append([prod, range(1, nSlides), nSlides])
    # params = {'no_of_slides': nSlides, 'range': range(1,nSlides), 'product': products}
    # allProds = [[products, range(1, nSlides), nSlides],
    #             [products, range(1, nSlides), nSlides]]
    params = {'allProds': allProds}
    return render(request, 'shop/index.html', params)




def searchMatch(query , item):
    '''return true only if query matches the item'''
    if query in item.description.lower() or query in item.product_name.lower() or query in item.category.lower():
        return True
    else:
        return False


def search(request):
    query = request.GET.get('search')
    allProds = []
    catProds = Product.objects.values('category', 'id')
    cats = {item['category'] for item in catProds}
    for cat in cats:
        prodtemp = Product.objects.filter(category=cat)
        prod = [item for item in prodtemp if searchMatch(query,item)]
        
        n = len(prod)
        nSlides = n // 4 + ceil((n / 4) - (n // 4))
        if len(prod)!=0:
            allProds.append([prod, range(1, nSlides), nSlides])   
    params = {'allProds': allProds ,"msg":""}
    if len(allProds) == 0 or len(query)<4:
        params = {'msg':"Please make sure to enter relevent search query"}
    return render(request, 'shop/search.html', params)



def about(request):
    return render(request, 'shop/about.html')


def contact(request):
    thanks = False
    if request.method == "POST":
        name = request.POST.get('name', '')
        email = request.POST.get('email', '')
        phone_no = request.POST.get('phone_no', '')
        description = request.POST.get('description', '')
        thanks = True
        contact = Contact(name=name, email=email, phone_no=phone_no, description=description)
        contact.save()
        return render(request, 'shop/contact.html', {'thanks': thanks})
    return render(request, 'shop/contact.html')


def tracker(request):
    if request.method == "POST":
        OrderId = request.POST.get('OrderId', '')
        email = request.POST.get('email', '')

        try:
            order = Orders.objects.filter(order_id=OrderId, email=email)
            if len(order) > 0:
                update = OrderUpdate.objects.filter(order_id=OrderId)
                updates = []
                for item in update:
                    updates.append({'text': item.update_description, 'time': item.timestamp})
                    response = json.dumps({"status":"success","updates":updates,"items-Json":order[0].item_json}, default=str)
                return HttpResponse(response)
            else:

                return HttpResponse('{"status":"no-item"}')
        except Exception as e:
            return HttpResponse('{"status":"error"}')

    return render(request, 'shop/tracker.html')



def productview(request, myid):
    # Fetch the product using the id
    product = Product.objects.filter(id=myid)
    print(product)

    return render(request, 'shop/prodview.html', {'product': product[0]})


def checkout(request):
    if request.method == "POST":
        item_json = request.POST.get('itemJson', "")
        name = request.POST.get('name', '')
        PRSamount_Rupies = request.POST.get('PRSamount_Rupies', '')
        email = request.POST.get('email', '')
        address = request.POST.get('address1', '') + " " + request.POST.get('address2', '')
        city = request.POST.get('city', '')
        state = request.POST.get('state', '')
        zip_code = request.POST.get('zip_code', '')
        phone = request.POST.get('phone', '')
        order = Orders(item_json=item_json, name=name, email=email, address=address, city=city, state=state,
                       zip_code=zip_code, phone=phone, PRSamount_Rupies=PRSamount_Rupies)
        order.save()
        update = OrderUpdate(order_id=order.order_id, update_description="The Order has been placed.")
        update.save()
        thank = True
        id = order.order_id

        # return render(request, 'shop/cheackout.html', {'thank': thank, 'id': id})

        # Request paytm to transfer the amount to your account after payment by user
        # return render(request, 'shop/checkout.html', {'thank':thank, 'id': id})
        # Request paytm to transfer the amount to your account after payment by user
        # Request paytm to transfer the amount to your account after payment by user
        # More Details: https://developer.paytm.com/docs/checksum/#python
        # paytmParams["MID"] = "ZSUcJi00923744078147"

        return render(request, 'shop/cheackout.html', {'thank':thank, 'id': id})
    #request paytm to transfer the amount to your account after payment by user
    #     param_dict={
    #
    #         'MID': 'WorldP64425807474247',
    #         'ORDER_ID': 'order.order_id',
    #         'TXN_AMOUNT': '1',
    #         'CUST_ID': 'email',
    #         'INDUSTRY_TYPE_ID': 'Retail',
    #         'WEBSITE': 'WEBSTAGING',
    #         'CHANNEL_ID': 'WEB',
    #         'CALLBACK_URL':'http://127.0.0.1:8000/shop/handlepayment/',
    #
    # }
    # return render(request, 'shop/checkout.html')
    #     param_dict['CHECKSUMHASH'] = Checksum.generate_checksum(param_dict, MERCHANT_KEY)
        # return render(request, 'shop/paytm.html', {'paytmParams': paytmParams})

        # return  render(request, 'shop/paytm.html', {'param_dict': param_dict})
    return render(request, 'shop/cheackout.html')


# @csrf_exempt
# def handlerequest(request):
#     # paytm will send you post request here
#    # paytm will send you post request here
#     form = request.POST
#     response_dict = {}
#     for i in form.keys():
#         response_dict[i] = form[i]
#         if i == 'CHECKSUMHASH':
#             checksum = form[i]
#
#     verify = Checksum.verify_checksum(response_dict, MERCHANT_KEY, checksum)
#     if verify:
#         if response_dict['RESPCODE'] == '01':
#             print('order successful')
#         else:
#             print('order was not successful because' + response_dict['RESPMSG'])
#     return render(request, 'shop/paymentstatus.html', {'response': response_dict})
   


   

def customerinfo(request):
    return HttpResponse("we are fetching info of the custumer")


def shipper(request):
    return HttpResponse("our product is  shipper or not")
